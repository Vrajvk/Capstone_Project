import React from "react";

function SearchMessages() {
  return <div>SearchMessages</div>;
}

export default SearchMessages;
