import Main from "../components/Main";
import React from "react";

function index() {
  return <Main />;
}

export default index;
